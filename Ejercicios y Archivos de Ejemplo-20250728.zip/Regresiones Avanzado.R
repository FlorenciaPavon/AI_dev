#Regresiones Lineales

#Utiles para ver relaciones entre variables, por ejemplo, usando MTCARS

str(penguins_lter)

#reducimos el set a una especia
Chinstrap <- subset(penguins_lter, Species == 'Chinstrap penguin (Pygoscelis antarctica)')

#lo que queremos comparar:

library(plotly)
library(EBImage)
#imagen
culmen = readImage("https://user-images.githubusercontent.com/54525819/139197232-91df7152-f6a9-4149-89d6-d04ad2cf021a.jpg")

imgculmen <- plot_ly(type="image", z=culmen*255)
imgculmen

#veamos el detalle del subset
str(Chinstrap)

#supongamos que queremos comparar la profundidad y largo del pico
plot(sort(Chinstrap$Culmen.Depth..mm.))
plot(sort(Chinstrap$Culmen.Length..mm.))

#veamos los datos crudos en un solo data frame
profundidad <-c(Chinstrap$Culmen.Depth..mm)
largo <- c(Chinstrap$Culmen.Length..mm.)

ChinstrapComparado <- data.frame(profundidad, largo)

str(ChinstrapComparado)
plot (ChinstrapComparado)

#interesante vemos que ambas variables crecen

#armemos la regresión con nuestra variable de salida (y) el largo
regresionpico = lm(largo~profundidad, data=ChinstrapComparado) #recordar que el primero es el eje y
print(regresionpico)

#vemos los detalles de la función
summary(regresionpico)

#residuales: distancia del punto de referencia.
#coeficientes
plot(regresionpico)


#volvemos a plotear los datos originales
plot (ChinstrapComparado)
#y agregamos la regresion
abline(regresionpico, col='red')

#eh voila

#Regresion multivariable

#Volvamos a pinguinos, usemos a Chinstraps
str(Chinstrap)

#ahora, veamos que pasa si traigo mas variables al analisis
profundidad <-c(Chinstrap$Culmen.Depth..mm)
largo <- c(Chinstrap$Culmen.Length..mm.)
peso <- c(Chinstrap$Body.Mass..g.)
largoAleta <- c(Chinstrap$Flipper.Length..mm.)

#y armemos el df
ChinstrapComparado2 <- data.frame(profundidad,largo,peso,largoAleta)

#confirmamos que esta todo bien
str(ChinstrapComparado2)

#y ploteamos todo
plot(ChinstrapComparado2)

#como afectan a peso las demas variables
Chinstrapmultiple <- lm(peso ~ largo + profundidad + largoAleta, data=ChinstrapComparado2)

#vemos los detalles de la regresion multivariable
print(Chinstrapmultiple)

#vemos el resumen
summary(Chinstrapmultiple)

#vemos el detalle ploteado
plot(Chinstrapmultiple)

plot(Chinstrap$Flipper.Length..mm.)

plot(iris)

plot(penguins_lter)
str(penguins_lter)

