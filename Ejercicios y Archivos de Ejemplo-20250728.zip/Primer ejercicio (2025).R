#Asigno variable, nombrando la variable y usando <- para asignar el valor

NumeroVariable <- 3
print(NumeroVariable)

#El tipo de dato que asigno se define en la asignación.

elmejordelmundo <- "Lionel Messi"
print(elmejordelmundo)

#Puedo operar entre numeros y variables facilmente

1+1

Sumador1 <- 10
Sumador2 <- 5
print(Sumador1+Sumador2)

#Los conjuntos de datos se pueden crear con esta estructura:

bolsaDeDatos <- c(5,6,7,8,9)
print (bolsaDeDatos)
plot(bolsaDeDatos)

#Ejercicios
#  ---------------------------------------
# Crar un hola mundo
# Crear una suma de dos variables en forma directa y con variables
# Crear una resta de dos variables en forma directa y con variables
# Calcular la potencia en forma directa y con variables
# plotear un conjunto de datos


