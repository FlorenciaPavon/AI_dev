# Ejercicio 9

#SE PERMITE INVESITGAR POR FUERA DE LOS MATERIALES DE SER NECESARIO
#ESTA GUIA NO SE ENVIA.
#SI QUIEREN PROBARLO EN PYTHON, ESTA DISPONIBLE EL SET EN PYTHON :)

#Este es un ejemplo genérico que pueden encontrar online ya que se usa bastante para todos los cursos de NN.

#Redes neuronales - Parte 2
##--------------


#NOTAS# esta guia esta pensada para que repliquen el proceso, no para armar una nueva aplicacion.

#Empezamos instalando la libreria de neural net para usar una ANN
install.packages("neuralnet")
install.packages("keras")
install.packages("tensorflow")
install.packages("tidyr")
install.packages("ggplot2")
install.packages("EBImage")
library(EBImage)
library(keras)
library(tensorflow)
library(tidyr)
library(ggplot2)

#Vamos a usar el set integrado en keras, MNIST. #Si parece que no responde, denle unos minutos, va a descargar 220 mb de datos. Son imagenes de 28 por 28 pixeles.

MODA <- dataset_fashion_mnist() 

#generamos particiones de entrenamiento y de prueba. Por simplicidad no hacemos esto al azar. Igualmente no sería tan al azar para esto (lo vemos en modelizado!!!)

c(img_entrenamiento, etiqueta_entrenamiento) %<-% MODA$train
c(img_prueba, etiqueta_prueba) %<-% MODA$test

#De acuerdo al set, estas son las clasificaciones (estan en inglés):
#0	T-shirt/top
#1	Trouser
#2	Pullover
#3	Dress
#4	Coat
#5	Sandal
#6	Shirt
#7	Sneaker
#8	Bag
#9	Ankle boot

etiquetas_ropa = c('T-shirt/top', 
                'Trouser',
                'Pullover',
                'Dress',
                'Coat',
                'Sandal',
                'Shirt',
                'Sneaker',
                'Bag',
                'Ankle boot')

#No se preocupen mucho por esta sintaxis. Es meramente para que ustedes puedan ver las imágenes. Corran todo el bloque junto.

imagen.ejemplo <- as.data.frame(img_entrenamiento[1, , ])#cambiando este numero pueden ver las imagenes del set.
colnames(imagen.ejemplo) <- seq_len(ncol(imagen.ejemplo))
imagen.ejemplo$y <- seq_len(nrow(imagen.ejemplo))
imagen.ejemplo <- gather(imagen.ejemplo, "x", "value", -y)
imagen.ejemplo$x <- as.integer(imagen.ejemplo$x)

ggplot(imagen.ejemplo, aes(x = x, y = y, fill = value)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "black", na.value = NA) +
  scale_y_reverse() +
  theme_minimal() +
  theme(panel.grid = element_blank())   +
  theme(aspect.ratio = 1) +
  xlab("") +
  ylab("")

#ahora, necesitamos reducir el valor de cada pixel  para escalarlo de 1 a 0
img_entrenamiento <- img_entrenamiento / 255
img_prueba <- img_prueba / 255

#Al rever las imagenes, veremos que la escala de grises cambio un poco
par(mfcol=c(5,5))
par(mar=c(0, 0, 1.5, 0), xaxs='i', yaxs='i')
for (i in 1:25) {
  img <- img_entrenamiento[i, , ]
  img <- t(apply(img, 2, rev))
  image(1:28, 1:28, img, col = gray((0:255)/255), xaxt = 'n', yaxt = 'n',
        main = paste(etiquetas_ropa[etiqueta_entrenamiento[i] + 1]))
  }

#Vamos a usar la red de Keras, no de neuralnet en este caso. Creamos el modelo de ews neuronal. La primera capa va a aplanar las imagenes (es decir, las va a vectorizar, o pasar los valores a vector, de 28 x 28 pixeles). La segunda capa la definimos con 128 neuronas , y la tercera con 10, con distintos tipos de activación.

modelo <- keras_model_sequential()
modelo %>%
  layer_flatten(input_shape = c(28, 28)) %>%
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dense(units = 10, activation = 'softmax')

#configuramos el modelo.
modelo %>% compile(
  optimizer = 'adam', #acá le indicamos el tipo de algoritmo para optimizar.
  loss = 'sparse_categorical_crossentropy', #nos indica que preciso es el modelo durante el entrenamiento.
  metrics = c('accuracy') #medimos la precisión del modelo.
)

#Y ahora llego el momento de entrenar el modelo. 
modelo %>% fit(img_entrenamiento, etiqueta_entrenamiento, epochs = 5, verbose = 2)

#No debería tardar mucho, porque no es un set tan grande, pero tengan paciencia. En mi primer intento con 5 epochs me demoro 10 segundos. Verbose en 2 me permite ver el proceso de entrenamiento. Dejenlo en 2, pero puede ser en 0 o 1 tambien.

#Una vez que se ejecuto el modelo esta entrenado. 

#Hora de probarlo contra el set de prueba.

score <- modelo %>% evaluate(img_prueba, etiqueta_prueba, verbose = 0)


#vemos la perdida o loss
cat('Test loss:', score["loss"], "\n")

#vemos la precisión
cat('Test accuracy:', score["accuracy"], "\n")



#vemos la predición
predicciones <- modelo %>% predict(img_prueba)

#podemos ver las predicciones individuales
predicciones[5, ] #cambiando el numero podemos ver la predicción para cada imagen


#y podemos plotear imagenes con sus predicciones
par(mfcol=c(5,5))
par(mar=c(0, 0, 1.5, 0), xaxs='i', yaxs='i')
for (i in 1:25) {
  img <- img_prueba[i, , ]
  img <- t(apply(img, 2, rev))
  etiqueta_pred <- which.max(predicciones[i, ]) - 1
  etiqueta_real <- etiqueta_prueba[i]
  if (etiqueta_pred == etiqueta_real) {
    color <- '#008800'
  } else {
    color <- '#bb0000'
  }
  image(1:28, 1:28, img, col = gray((0:255)/255), xaxt = 'n', yaxt = 'n',
        main = paste0(etiquetas_ropa[predicted_label + 1], " (",
                      etiquetas_ropa[etiqueta_real + 1], ")"),
        col.main = color)
}

#O probandolo para una imagen individual
img <- img_prueba[9, , , drop = FALSE] #cambiando el numero cambiamos la imagen
dim(img) #para asegurarnos que las dimensiones sean efectivamente de 28x28 (meramente para verlo)

predicciones <- modelo %>% predict(img) #predicción

predicciones #vemos como nos devuelve el array

#vemos la predicción especifica.
prediccion <- predicciones[1, ] - 1
which.max(prediccion)

#recordando los labels:
#0	T-shirt/top
#1	Trouser
#2	Pullover
#3	Dress
#4	Coat
#5	Sandal
#6	Shirt
#7	Sneaker
#8	Bag
#9	Ankle boot

#para verla
imagen.prueba <- as.data.frame(img_prueba[9, , ])#cambien por la imagen que usen arriba para probar
colnames(imagen.prueba) <- seq_len(ncol(imagen.prueba))
imagen.prueba$y <- seq_len(nrow(imagen.prueba))
imagen.prueba <- gather(imagen.prueba, "x", "value", -y)
imagen.prueba$x <- as.integer(imagen.prueba$x)

ggplot(imagen.prueba, aes(x = x, y = y, fill = value)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "black", na.value = NA) +
  scale_y_reverse() +
  theme_minimal() +
  theme(panel.grid = element_blank())   +
  theme(aspect.ratio = 1) +
  xlab("") +
  ylab("")

#Ejercicio unico

# replicar con otro set integrado. El set CIFAR10 (requiere 700mb)
#para empezar
cifar10 = dataset_cifar10()



