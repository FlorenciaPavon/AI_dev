# Ejercicio 10

#SE PERMITE INVESITGAR POR FUERA DE LOS MATERIALES DE SER NECESARIO

#Hoy cambiamos el orden del ejercicio. El codigo funciona (TESTADO EN VERSIONES 4.3.1 y 4.3.3), pero hoy el objetivo es analizar el codigo y agregar los comentarios de que esta haciendo espeficicamente en cada bloque. Para facilitarlo, les comente de bloque en bloque.

#Los dos primeros usan el mismo set. Recomiendo limpiar datos, e incluso reiniciar R antes de empezar el tercero. Si por algun motivo el tercero no corre, pruebenlo en la maquina de mayor memoria de su grupo.

#Librerias a usar
install.packages("janeaustenr")
install.packages("dplyr")
install.packages("stringr")
install.packages("tidytext")
install.packages("wordcloud") 
install.packages("textdata")
install.packages("reshape2")
library(janeaustenr)
library(dplyr)
library(stringr)
library(tidytext)
library(ggplot2)
library(wordcloud) 
library(textdata)
library(tidyr)
library(reshape2)



#Ejercicio 1: Análisis de textos


##---- carga de datos de libros

libros_austen <- austen_books() %>%
  group_by(book) %>%
  mutate(linenumber = row_number(),
         chapter = cumsum(str_detect(text, regex("^chapter [\\divxlc]",
                                                 ignore_case = TRUE)))) %>%
  ungroup()

libros_austen

##---- tokenizacion

orden_libros <- libros_austen %>%
  unnest_tokens(word, text)

orden_libros

#---palabras vacias (stop words)

data(stop_words)

orden_libros <- orden_libros %>%
  anti_join(stop_words)

#---frecuencias

orden_libros %>%
  count(word, sort = TRUE) 

orden_libros %>%
  count(word, sort = TRUE) %>%
  filter(n > 600) %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()

#----nube
orden_libros %>%
  anti_join(stop_words) %>%
  count(word) %>%
  with(wordcloud(word, n, max.words = 100))

#Ejercicio #2 - Análisis de sentimientos - Usando también el set de Jane Austeen

library(tidytext)
library(textdata)

#--- diccionario de relación de palabras con sentimiento
get_sentiments("bing")
get_sentiments("nrc")

##----libro

orden_libros <- austen_books() %>%
  group_by(book) %>%
  mutate(linenumber = row_number(),
         chapter = cumsum(str_detect(text, regex("^chapter [\\divxlc]", 
                                                 ignore_case = TRUE)))) %>%
  ungroup() %>%
  unnest_tokens(word, text)
orden_libros

##---Carga del lexicon nrc
analisis_nrc_felicidad <- get_sentiments("nrc") %>% 
  filter(sentiment == "joy")

orden_libros %>%
  filter(book == "Emma") %>%
  inner_join(analisis_nrc_felicidad) %>%
  count(word, sort = TRUE)

##---sentimientos con bing
analisis_bing_sentimientos <- orden_libros %>%
  inner_join(get_sentiments("bing")) %>%
  count(book, index = linenumber %/% 80, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative) #ignorar el warning

analisis_bing_sentimientos

##--- ploteamos

ggplot(analisis_bing_sentimientos, aes(index, sentiment, fill = book)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~book, ncol = 2, scales = "free_x")

#cloud
orden_libros %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("red", "green"),
                   max.words = 100)

# Ejercicio 3 - Clasificador de texto
library(keras)
library(tensorflow)

# -- carga de datos (va a demorar unos segundos)
imdb <- dataset_imdb(num_words = 10000)
data_entrenamiento <- imdb$train$x
etiqueta_entrenamiento <- imdb$train$y
data_prueba <- imdb$test$x
etiqueta_prueba <- imdb$test$y

#---- indices
indice_palabras <- dataset_imdb_word_index()  
indice_palabras_inv <- names(indice_palabras)
names(indice_palabras_inv) <- indice_palabras

#visualizacion en texto plano
resena_textoplano <- sapply(data_entrenamiento[[1]], function(index) {
  word <- if (index >= 3) indice_palabras_inv[[as.character(index - 3)]]
  if (!is.null(word)) word else "?"
})
cat(resena_textoplano)

#---vectorizacion de datos

secuencias_vectorizadas <- function(sequences, dimension = 10000) {
  results <- matrix(0, nrow = length(sequences), ncol = dimension) 
  for (i in 1:length(sequences))
       results[i, sequences[[i]]] <- 1 
  results
}


x_train <- secuencias_vectorizadas(data_entrenamiento)
x_test <- secuencias_vectorizadas(data_prueba)

y_train <- as.numeric(etiqueta_entrenamiento)
y_test <- as.numeric(etiqueta_prueba)


#---- Construccion del modelo
modelo_nn <- keras_model_sequential() %>% 
  layer_dense(units = 16, activation = "relu", input_shape = c(10000)) %>% 
  layer_dense(units = 16, activation = "relu") %>% 
  layer_dense(units = 1, activation = "sigmoid")

#---- compilacion del modelo - ignorar warnings
modelo_nn %>% compile(
  optimizer = optimizer_rmsprop(lr=0.001),
  loss = "binary_crossentropy",
  metrics = c("accuracy")
)

#datos de validacion
val_indices <- 1:10000

x_val <- x_train[val_indices,]
partial_x_train <- x_train[-val_indices,]

y_val <- y_train[val_indices]
partial_y_train <- y_train[-val_indices]

#entrenamiento en batches
historial_entrenamiento <- modelo_nn %>% keras::fit(
  partial_x_train,
  partial_y_train,
  epochs = 10,
  batch_size = 512,
  validation_data = list(x_val, y_val)
)
plot(historial_entrenamiento)

#---ajustando el modelo

modelo_nn <- keras_model_sequential() %>% 
  layer_dense(units = 16, activation = "relu", input_shape = c(10000)) %>% 
  layer_dense(units = 16, activation = "relu") %>% 
  layer_dense(units = 1, activation = "sigmoid")

modelo_nn %>% compile(
  optimizer = "rmsprop",
  loss = "binary_crossentropy",
  metrics = c("accuracy")
)


# ---- verificando
modelo_nn %>% keras::fit(x_train, y_train, epochs = 4, batch_size = 512)
results <- modelo_nn %>% evaluate(x_test, y_test)
results

val_indices <- 1:10000

x_val <- x_train[val_indices,]
partial_x_train <- x_train[-val_indices,]

y_val <- y_train[val_indices]
partial_y_train <- y_train[-val_indices]

historial_entrenamiento <- modelo_nn %>% keras::fit(
  partial_x_train,
  partial_y_train,
  epochs = 10,
  batch_size = 512,
  validation_data = list(x_val, y_val)
)
plot(historial_entrenamiento)
