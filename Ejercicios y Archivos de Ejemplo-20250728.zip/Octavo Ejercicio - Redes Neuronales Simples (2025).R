Ejercicio

#SE PERMITE INVESITGAR POR FUERA DE LOS MATERIALES DE SER NECESARIO
#AL FINALIZAR LA CLASE ENVIEN UNA COPIA POR GRUPO A emilio.leon@bue.edu.ar


#Arboles de clasificación
##--------------
#NOTAS

#Empezamos instalando la libreria de neural net para usar una ANN
install.packages("neuralnet")
library(neuralnet)
library(tidyverse)

#Recordamos como era iris
data(iris)
head(iris)
str(iris)

#generamos las particiones de prueba y entrenamiento (esta es otra manera de generarla, podemos hacerlo de la misma manera que lo hicimos con arboles también)
indice.prueba <- sample(nrow(iris), nrow(iris) / 3)
str(indice.prueba)
prueba <- iris[indice.prueba, ]
entrenamiento <- iris[-indice.prueba, ]

#pasamos los datos por la red neuronal, tratando de predecir las especies, es decir, las neuronas de salida corresponderían a la variable "Species" del set, e indicamos que datos insertamos
red.neuronal <- neuralnet(as.numeric(Species) ~ Sepal.Length + Sepal.Width + 
                   Petal.Length + Petal.Width, entrenamiento, hidden = c(10,5))

#Podemos ver los detalles de pesos y valores dentro de la red y en cada capa
print(red.neuronal)

#Si ploteamos la red, veremos los pesos calculados para las activaciones así como sesgos si corresponden:
plot(red.neuronal, rep = "best")

#Viendo el impacto de cada variable en la red:
par(mfrow=c(2,2))
gwplot(red.neuronal, selected.covariate = "Sepal.Length")
gwplot(red.neuronal, selected.covariate = "Sepal.Width")
gwplot(red.neuronal, selected.covariate = "Petal.Length")
gwplot(red.neuronal, selected.covariate = "Petal.Width")

#y de paso vemos algunos outliers

#Ahora usamos la partición de prueba para verificar como funciona
output <- neuralnet::compute(red.neuronal, prueba[ , c("Sepal.Length", "Sepal.Width", "Petal.Length", "Petal.Width")])

#Una nota sobre esto, la instrucción Compute la tenemos en varias librerias, entonces para forzar la correcta indicamos de donde la toma, por eso neuralnet::compute en lugar de solo compute, si no cargara tidyverse, podría hacerlo solo con compute ;)

#y hacemos la comparación entre lo real y lo que se predijo con la red, de los datos de prueba
resultado <- data.frame(
  Real = prueba$Species, 
  Prediccion = levels(iris$Species)[round(output$net.result)])

#y lo vemos
print(resultado)


#armando una confusion matrix para la red:

pred <- predict(red.neuronal, prueba)
etiquetas <- c("setosa", "versicolor", "virginca")
etiqueta.prediccion <- data.frame(max.col(pred)) %>%    
  mutate(pred=etiquetas[max.col.pred.]) %>%
  select(2) %>%
  unlist()

#vemos la prediccion segun la matrix

table(prueba$Species, etiqueta.prediccion)

#y la predicción contra

#vemos la precision contra lo real
tabla.predicciones <- table(resultado$Prediccion, resultado$Real)
print(tabla.predicciones)

#Ejercicio 1: Usando uno de los datasets integrados aplicar la red neuronal.

#Ejercicio 2: Crear un dataset basado en pinguinos y aplicar esta red neuronal.

#Ejercicio 3: Elegir un set de Kaggle y aplicar la NN.

#Preparar los datos adecuadamente en todos los casos.

