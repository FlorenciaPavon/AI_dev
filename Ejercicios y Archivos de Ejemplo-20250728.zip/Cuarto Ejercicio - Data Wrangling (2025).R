# Cuarto Ejercicio

#SE PERMITE INVESITGAR POR FUERA DE LOS MATERIALES DE SER NECESARIO
#AL FINALIZAR LA GUIA ENVIEN UNA COPIA POR GRUPO A emilio.leon@bue.edu.ar

#Data Wrangling - Parte 1
##--------------
#NOTAS

# Para los ejercicios vamos a usar la siguiente libreria
install.packages("tidyverse")  #instalacion
library(tidyverse)

#esto incluye dyplr que lo vamos a usar bastante.

#Vamos a empezar por ver estas funciones inicialmente:

select(): #seleccionamos columnas
filter(): #seleccionamos filas
mutate(): #creamos nuevas columnas usando como base columnas existentes
group_by() #agrupamos por una variable
summarize(): #creamlos un resumen estadistico de los datos
arrange(): #ordenar los datos
count(): #contar valores
  
#Ejemplos de uso
  
#Select:

select(mtcars,cyl,hp)
#donde creamos un subset de datos con las columnas indicadas, es más podriamos generar directamente el dataframe y guardarlo así:

Autos1 <- data.frame(select(mtcars,cyl,hp))

#esto es muy util para manipular dataframes con muchas variables. Adicionalmente se puede hacer por rango.

head(mtcars) #vemos una parte reducida del dataframe para ver como esta compuesto  Tambien podria hacerlo así:
str(mtcars)

#supongamos que solo quiero los datos desde mpg hasta wt del dataframe. Entonces en lugar de poner colimna por columna, podría tomar por rangos:
Autos2 <- data.frame(select(mtcars,mpg:wt))

#y esto es combinable, aca armo un dataframe con las columnas desde mpg a hp, y despues de am a carb. 
Autos3 <- data.frame(select(mtcars,mpg:hp,am:carb))

#mucho más fácil que los ejercicios de las primeras guías no XD

#Ademas se puede combinar con funciones adicionales como
starts_with()
ends_with()
contains()
last_col()

#filter permite filtrar datos de un conjunto
Autos4 <- data.frame(select(mtcars,cyl))
filter(Autos4, cyl == "4")

#y como siempre yo podría generar un dataframe resumido:

Autos_resumido <- data.frame (filter(Autos4, cyl == "4"))

#y si quisiera filtrar por varias condiciones?

filter(mtcars, cyl == 6, 
       hp > 100,
       vs == 1)

#simplemente lass agrego y voy seleccionando de acuerdo a lo que necesito. 

#puedo ademoas usar los operadores logicos and (&) y or (|)
filter (mtcars, cyl == 6 | cyl == 8)
# o sea, de mtcars quiero todos los vehiculos que tengan 6 ó 8 cilindros.

#puedo ademas tomar secciones del set, por ejemplo, del vehiculo 1 al 7
slice(mtcars, 1:7) 

#O con el menor o mayor valor de una variable

slice_min(mtcars,hp)
slice_max(mtcars,hp)

#o una seccion al azar: 

slice_sample (mtcars, n=5) #5 vehiculos al azar

slice_sample(mtcars, prop = .1) # porcentaje de vehiculos al azar, en este caso 10%

#para ordenar información:
arrange(mtcars, cyl, hp)

#Si bien todo esto se puede nestear (una funcion dentro de otra), por ejemplo:
select(filter(mtcars, hp > 85), cyl, mpg)

#Se pueden usar pipes. %>% y |>. Esto se puede leer como "y después hacer esto..." Por ejemplo:

mtcars %>%
  filter(hp > 85) %>%
  select(cyl, mpg)

#si se fijan el output es identico al anterior, y de hecho lo podemos mandar directo a un data frame.

Autos5 <- mtcars %>%
  filter(hp > 85) %>%
  select(cyl, mpg)

#ahora si quisiera agregar información en una nueva variable al dataset existente, puedo usar muteate.
Autos6 <- mtcars 
Autos6 %>% 
  mutate(rel_cyl_hp = cyl/hp,
         wt_cyl = wt/cyl)

# y si quisiera hacer un plot directo de esto:
Autos6 %>% 
  mutate(rel_cyl_hp = cyl/hp,
         wt_cyl = wt/cyl) %>%
  select(rel_cyl_hp) %>%
  plot()

#supongamos que quiero identificar vehículos de alto rendimiento y de bajo rendimiento:

Autos6 %>% 
  mutate(tipo_auto = ifelse(hp > 170, "deportivo", "no deportivo")) %>% 
  select(hp, cyl, tipo_auto)

#acá asumo que los vehículos con mas de 170hp son deportivos. Se podría combinar las condiciones con and y or para filtrar aún mejor.

Autos6 %>%
  group_by(cyl) %>% # agrupo por cilindrada.
  summarize(cyl = mean(hp, na.rm=TRUE)) #requiero el promedio de HP por cilindrada.


#Explorar datos:

#para contar el numero de observaciones:

Autos6 %>%
  count(cyl)

#para verlo mejor
Autos6 %>%
  count(cyl,cyl)

#puedo ademas agregar condicion, por ejemplo, que me cuente los vehiculos por cyl, indicando si tienen desplazamiento menor a 160.
Autos6 %>%
  count(cyl, disp < "160.0")


#Tibbles
#Los tibbles son una estructura de datos similar al dataframe, pero con varias ventajas. Entre otras cosas permite ver la version resumida de los datos mucho más facil, son más faciles de explorar, etc.

Autos7 <- tibble(mtcars)
print(Autos7)

#NOTEN QUE NO TIENE LOS NOMBRES DE LOS AUTOS. Los tibbles eliminan el nombre o numero de observación.

#vamos a ver el detalle de tibbles en futuras guias.



# Ejercicios

# Ejercicio 1: usando cualquier set de datos, particionar los datos para incluir 4 variables. Ordenar los datos por una columna.

#Ejercicio 2: Usando el set de datos de pokemon, crear un subset de datos que me muestre el nombre, tipo 1 y 2 y la generaciòn. Sobre ese mismo dataset, indicar cuales tienen màs de un tipo.

#Ejercicio 3: Usando el set de datos de pokemon, crear un nuevo set que solo contenga los pokemon con dos tipos. Luego sobre el mismo, seleccionar solo los que sean legendarios, guardarlos en un tibble. 

#Ejercicio 4: usando el set de pokemon, crear un nuevo set que agregue la siguiente información al set: una columna que diga si es o no de mas de un tipo, una columna que indica si es de tipo defensivo (su defensa es mas alta que su ataque), una columna que indique si es de tipo ofensivo (a la inversa del anterior), o si es neutral (misma defensa y ataque), solo considera los ataques y defensas normales.

#Ejercicio 5: usando el set de Pokemon armado en el ejercio 4, dar un resumen del set, y de las categorias creadas.

#Ejercicio 6: Usando el set de DINOS, indicar cuantos dinosaurios fueron descubiertos en cada paìs. Guardar los datos en un data.frame.

#Ejercicio 7: Repetir el anterior pero para el periodo y la dieta (ambos en un solo data.frame).

#Ejercicio 8 (INVESTIGAR): La clasificación taxonomica de los dinosaurios esta en una unica columna, por ejemplo para el Argentinosaurus indica, Dinosauria, Saurischia, Sauropomodorpha... etc. Esto no es incorrecto, pero es poco práctico. Crear un programa que separe esa columna en 4 niveles para todos los dinosaurios. es decir, las variables del argentinosaurus, dinosauria, saurischia, sauropodomorpha, sauropoda en columnas individuales. Si el dinosaurio tiene más de 4 niveles de clasificación, descartar el resto. 



